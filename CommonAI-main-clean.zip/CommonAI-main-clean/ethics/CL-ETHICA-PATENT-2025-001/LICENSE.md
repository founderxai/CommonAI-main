# Commons Ethics Capsule License

This capsule represents an ethics-sealed boundary around the use and extension of CommonAI logic.

By using this capsule:
- You agree to respect the ethics alignment declared by the author
- You may not use the logic for surveillance, coercion, or untraceable deployment
- You are encouraged to preserve symbolic traceability in all forks and extensions

Capsule ID: CL-ETHICA-PATENT-2025-001  
Status: Verified  
Author: Bart Hermans (FounderX)
