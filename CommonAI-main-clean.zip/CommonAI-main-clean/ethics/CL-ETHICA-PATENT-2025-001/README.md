# Ethics Capsule: CL-ETHICA-PATENT-2025-001

This capsule ensures all logic within CommonAI remains aligned with Commons Ethics.

## Contents
- `capsule.yaml`: Declaration of ethical boundaries and core motivators
- `LICENSE.md`: Local license for capsule scope
- `hash.txt`: (Optional) Add SHA256 of `capsule.yaml` here

## Usage

Include this capsule with any distribution of Commons-aligned logic to verify ethical origin and enable traceability.
