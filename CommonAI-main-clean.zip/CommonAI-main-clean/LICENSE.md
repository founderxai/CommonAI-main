# CommonsAI Use License (Ethics Aligned)

This software is released for Commons-aligned, educational, and public-good use.

You may:
- Use, fork, or extend this repository for research, educational, and non-exploitative projects
- Integrate with Commons Gateway and Commoncy-aligned infrastructure

You may not:
- Use this logic for coercive, manipulative, or militarized purposes
- Commercialize components without attribution and clear ethics pathway

Use is bound to the ethics capsule included in `ethics/`.

Author: Bart Hermans (FounderX)
